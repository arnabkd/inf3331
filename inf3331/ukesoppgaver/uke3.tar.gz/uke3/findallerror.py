import re #was missing import statement

#Numbers were not grouped properly together when in scientific notation format
#Added () around (\d+(\.\d*)?|\d*\.\d+)([eE][+\-]?\d+)?
real = \
 r"\s*(?P<number>-?((\d+(\.\d*)?|\d*\.\d+)([eE][+\-]?\d+)?))\s*"
c = re.compile(real)
some_interval = "[3.58652e+05 , 6E+09]"
groups = c.findall(some_interval)
lower = float(groups[0][c.groupindex['number']]) #1 changed to 0
upper = float(groups[1][c.groupindex['number']]) #2 changed to 1

#"%.5e" for scientific notation after 5 decimals
print "%.5e" %lower
print "%.5e" %upper


#Kjoreeksempel
#arnabkd@spes ~/Desktop/uni/inf3331/inf3331/ukesoppgaver/uke3 $ python findallerror.py 
#3.58652e+05
#6.00000e+09
